#include "replace.hh"
#include <fstream>
#include <iostream>
#include <string>

void replace(const std::string& input_filename,
             const std::string& output_filename,
             const std::string& src_token,
             const std::string& dst_token)
{
    std::ifstream input(input_filename);
    if (!input)
    {
        std::cerr << "Cannot open input file" << std::endl;
        return;
    }

    std::ofstream output(output_filename);
    if (!output)
    {
        std::cerr << "Cannot write output file" << std::endl;
        return;
    }

    if (src_token.empty())
    {
        output << input.rdbuf();
        return;
    }

    std::string line;
    while (std::getline(input, line))
    {
        std::size_t pos = 0;
        while ((pos = line.find(src_token, pos)) != std::string::npos)
        {
            line.replace(pos, src_token.length(), dst_token);
            pos += dst_token.length();
        }

        output << line;
        if (!input.eof())
            output << '\n';
    }
}
