#ifndef REPLACE_HH
#define REPLACE_HH

#include <string>

void replace(const std::string& input_filename,
             const std::string& output_filename,
             const std::string& src_token,
             const std::string& dst_token);

#endif
