package fr.epita.assistants.drawing;

public abstract class Entity implements Drawable {

    protected static int SEQUENCE = 0;
    protected final int id;

    public Entity() {
        SEQUENCE++;
        this.id = SEQUENCE;
    }

    public int getId() {
        return id;
    }
}