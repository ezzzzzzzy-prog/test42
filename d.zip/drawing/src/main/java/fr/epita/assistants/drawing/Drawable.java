package fr.epita.assistants.drawing;

public interface Drawable {
    void draw();
    default void display() {
        draw();
    }
}