package fr.epita.assistants.drawing;

public class Square extends Rectangle {

    public Square(int length) {
        super(length, length);
    }
}