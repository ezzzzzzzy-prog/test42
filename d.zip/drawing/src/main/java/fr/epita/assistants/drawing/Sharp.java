package fr.epita.assistants.drawing;

public abstract class Sharp extends Entity {
}