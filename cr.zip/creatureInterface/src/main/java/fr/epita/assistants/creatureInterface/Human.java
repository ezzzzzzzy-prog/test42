package fr.epita.assistants.creatureInterface;

public class Human extends BaseHuman {
    public Human(String name) {
        super(name);
    }
}
