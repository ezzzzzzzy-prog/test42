package fr.epita.assistants.creatureInterface;

import java.util.HashSet;
import java.util.Set;

public class Mage extends BaseHuman implements Magical {

    protected int mana;
    protected Set<Spell> spells;

    public Mage(String name, int mana) {
        super(name);
        this.mana = mana;
        this.spells = new HashSet<>();
    }

    @Override
    public int getMana() {
        return mana;
    }

    @Override
    public Set<Spell> getSpells() {
        return spells;
    }

    @Override
    public void addSpell(Spell spell) {
        spells.add(spell);
    }

    @Override
    public void castSpell(Spell spell) {
        if (!spells.contains(spell)) {
            System.out.println(name + " does not know " + spell.name() + ".");
            return;
        }
        if (mana < spell.getManaCost()) {
            System.out.println(name + " does not have enough mana.");
            return;
        }
        mana -= spell.getManaCost();
        System.out.println(name + " casts " + spell.name() + ".");
    }

    @Override
    public void regenMana(int mana) {
        if (swimming) {
            this.mana += (int) (mana * 0.9);
        } else {
            this.mana += mana;
        }
    }

    @Override
    public void greet(Speaker contact) {
        if (contact instanceof Mage) {
            System.out.println("I welcome you, " + contact.getName() + ".");
        } else {
            super.greet(contact);
        }
    }
}
