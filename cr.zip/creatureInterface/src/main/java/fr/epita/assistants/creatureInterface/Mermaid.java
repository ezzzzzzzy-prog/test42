package fr.epita.assistants.creatureInterface;

import java.util.HashSet;
import java.util.Set;

public class Mermaid extends Creature implements Swimmer, Speaker, Magical {

    private boolean swimming;
    private int mana;
    private Set<Spell> spells;

    public Mermaid(BaseHuman human, Fish fish) {
        super(
                human.getName().substring(0, 1).toUpperCase()
                        + human.getName().substring(1).toLowerCase()
                        + fish.getName().toLowerCase()
        );

        this.swimming = human.getSwimmingState();
        this.mana = 0;
        this.spells = new HashSet<>();

        if (human instanceof Mage mage) {
            for (Spell s : mage.getSpells()) {
                if (s.getSpellType() == SpellType.WATER || s.getSpellType() == SpellType.NEUTRAL) {
                    spells.add(s);
                } else {
                    System.out.println(name + " forgot the spell " + s.name() + ".");
                }
            }
        }
    }

    @Override
    public void swim() {
        swimming = true;
        System.out.println("I'm a Mermaid and I'm swimming.");
    }

    @Override
    public boolean getSwimmingState() {
        return swimming;
    }

    @Override
    public void emerge() {
        swimming = false;
    }

    @Override
    public void hello() {
        System.out.println("Hello, my name is " + name + " and I'm a Mermaid.");
    }

    @Override
    public int getMana() {
        return mana;
    }

    @Override
    public Set<Spell> getSpells() {
        return spells;
    }

    @Override
    public void addSpell(Spell spell) {
        if (spell.getSpellType() == SpellType.FIRE) {
            System.out.println("Mermaid cannot learn FIRE spells.");
            return;
        }
        spells.add(spell);
    }

    @Override
    public void castSpell(Spell spell) {
        if (!spells.contains(spell)) {
            System.out.println(name + " does not know " + spell.name() + ".");
            return;
        }

        int cost = spell.getManaCost();
        if (swimming && spell.getSpellType() == SpellType.WATER) {
            cost = (int) (cost * 0.6);
        }

        if (mana < cost) {
            System.out.println(name + " does not have enough mana.");
            return;
        }

        mana -= cost;
        System.out.println(name + " casts " + spell.name() + ".");
    }

    @Override
    public void regenMana(int mana) {
        this.mana += mana;
    }

    @Override
    public void greet(Speaker contact) {
        if (contact instanceof Mermaid) {
            System.out.println("Dear " + contact.getName() + ", welcome.");
        } else {
            Speaker.super.greet(contact);
        }
    }
}
