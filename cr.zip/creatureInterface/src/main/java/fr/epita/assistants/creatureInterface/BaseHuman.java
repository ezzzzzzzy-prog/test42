package fr.epita.assistants.creatureInterface;

public abstract class BaseHuman extends Creature implements Swimmer, Speaker {

    protected boolean swimming;

    public BaseHuman(String name) {
        super(name);
        this.swimming = false;
    }

    @Override
    public void swim() {
        swimming = true;
        System.out.println("I'm a " + getClass().getSimpleName() + " and I'm swimming.");
    }

    @Override
    public boolean getSwimmingState() {
        return swimming;
    }

    @Override
    public void emerge() {
        swimming = false;
    }

    @Override
    public void hello() {
        System.out.println("Hello, my name is " + name + " and I'm a " + getClass().getSimpleName() + ".");
    }

    @Override
    public void greet(Speaker contact) {
        if (contact instanceof Human) {
            System.out.println("Hello " + contact.getName() + ", how are you?");
        } else {
            Speaker.super.greet(contact);
        }
    }
}
