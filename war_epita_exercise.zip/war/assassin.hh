#ifndef ASSASSIN_HH
#define ASSASSIN_HH

#include "soldier.hh"

class Assassin : public Soldier
{
public:
    Assassin();
    void scream() const override;
};

#endif
