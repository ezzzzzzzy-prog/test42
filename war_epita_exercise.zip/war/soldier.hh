#ifndef SOLDIER_HH
#define SOLDIER_HH

#include <iostream>

class Soldier
{
public:
    Soldier(int health, int damage);
    virtual ~Soldier() = default;

    void attack(Soldier& s);
    void print_state() const;
    virtual void scream() const = 0;

protected:
    int health_;
    int damage_;
};

#endif
