#ifndef KNIGHT_HH
#define KNIGHT_HH

#include "soldier.hh"

class Knight : public Soldier
{
public:
    Knight();
    void scream() const override;
};

#endif
