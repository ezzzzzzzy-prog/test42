#include "regiment.hh"

void Regiment::join_by(Regiment& r)
{
    for (Soldier* s : r.soldiers_)
        soldiers_.push_back(s);

    r.soldiers_.clear();
}

std::size_t Regiment::count() const
{
    return soldiers_.size();
}

void Regiment::add_soldier(Soldier* s)
{
    soldiers_.push_back(s);
}

void Regiment::print_state() const
{
    for (const Soldier* s : soldiers_)
        s->print_state();
}

void Regiment::scream() const
{
    for (const Soldier* s : soldiers_)
        s->scream();
}
