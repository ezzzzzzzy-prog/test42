#ifndef REGIMENT_HH
#define REGIMENT_HH

#include <vector>
#include "soldier.hh"

class Regiment
{
public:
    void join_by(Regiment& r);
    std::size_t count() const;
    void add_soldier(Soldier* s);
    void print_state() const;
    void scream() const;

private:
    std::vector<Soldier*> soldiers_;
};

#endif
