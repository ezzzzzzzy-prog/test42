#include "int_container.hh"
#include <iostream>

MyIntContainer::MyIntContainer(std::size_t size)
    : data_(std::make_unique<int[]>(size))
    , capacity_(size)
    , length_(0)
{}

void MyIntContainer::print() const
{
    for (std::size_t i = 0; i < length_; ++i)
    {
        std::cout << data_[i];
        if (i + 1 < length_)
            std::cout << " | ";
    }
    std::cout << '\n';
}

std::size_t MyIntContainer::get_len() const
{
    return length_;
}

bool MyIntContainer::add(int elem)
{
    if (length_ >= capacity_)
        return false;

    data_[length_] = elem;
    ++length_;
    return true;
}

std::optional<int> MyIntContainer::pop()
{
    if (length_ == 0)
        return std::nullopt;

    --length_;
    return data_[length_];
}

std::optional<int> MyIntContainer::get(std::size_t position) const
{
    if (position >= length_)
        return std::nullopt;

    return data_[position];
}

std::optional<std::size_t> MyIntContainer::find(int elem) const
{
    for (std::size_t i = 0; i < length_; ++i)
    {
        if (data_[i] == elem)
            return i;
    }
    return std::nullopt;
}

void MyIntContainer::sort()
{
    for (std::size_t i = 0; i < length_; ++i)
    {
        for (std::size_t j = i + 1; j < length_; ++j)
        {
            if (data_[j] < data_[i])
            {
                int tmp = data_[i];
                data_[i] = data_[j];
                data_[j] = tmp;
            }
        }
    }
}

bool MyIntContainer::is_sorted() const
{
    if (length_ < 2)
        return true;

    for (std::size_t i = 1; i < length_; ++i)
    {
        if (data_[i] < data_[i - 1])
            return false;
    }
    return true;
}
