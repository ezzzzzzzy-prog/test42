#ifndef INT_CONTAINER_HH
#define INT_CONTAINER_HH

#include <memory>
#include <optional>
#include <cstddef>

class MyIntContainer
{
public:
    explicit MyIntContainer(std::size_t size);

    void print() const;
    std::size_t get_len() const;

    bool add(int elem);
    std::optional<int> pop();
    std::optional<int> get(std::size_t position) const;
    std::optional<std::size_t> find(int elem) const;

    void sort();
    bool is_sorted() const;

private:
    std::unique_ptr<int[]> data_;
    std::size_t capacity_;
    std::size_t length_;
};

#endif
